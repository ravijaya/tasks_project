from mymodule2 import RemovalService
from psupload import UploadService

import mock
import pytest


# Option 1: Mocking Instance Methods



@mock.patch('mymodule2.os.path')
@mock.patch('mymodule2.os')
def test_rm(mock_os, mock_path):
    # instantiate our service
    reference = RemovalService()

    # set up the mock
    mock_path.isfile.return_value = False

    reference.rm("any path")

    # test that the remove call was NOT called.
    assert mock_os.remove.called==False, "Failed to not remove the file if not present."

    # make the file 'exist'
    mock_path.isfile.return_value = True

    reference.rm("any path")

    mock_os.remove.assert_called_with("any path")



@mock.patch.object(RemovalService, 'rm')
def test_upload_complete(mock_rm):
    # build our dependencies
    removal_service = RemovalService()
    reference = UploadService(removal_service)

    # call upload_complete, which should, in turn, call `rm`:
    reference.upload_complete("my uploaded file")

    # check that it called the rm method of any RemovalService
    mock_rm.assert_called_with("my uploaded file")

    # check that it called the rm method of _our_ removal_service
    removal_service.rm.assert_called_with("my uploaded file")