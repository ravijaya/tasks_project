import unittest

def setUpModule():
    print "fix for the module"


def tearDownModule():
    print "fix for the module"


class FixturesTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print 'In setUp()'
        cls.fixture = range(1, 10)

    @classmethod
    def tearDownClass(cls):
        print 'In tearDown()'
        del cls.fixture

    def test_alpha(self):
        print 'In test()'
        self.assertEqual(self.fixture, range(1, 10))

    def test_beta(self):
        print 'In test()'
        self.assertIn(self.fixture[3], range(1, 10))

if __name__ == '__main__':
    unittest.main()
