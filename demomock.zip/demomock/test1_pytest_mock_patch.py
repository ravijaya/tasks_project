from mymodule import rm

import mock
import pytest



@mock.patch('mymodule.os')
def test_rm(mock_os, capsys):
    rm("any path")
    # test that rm called os.remove with the right parameters
    #with capsys.disabled():
    #    print dir(mock_os.remove)
    mock_os.remove.assert_called_with("any path")

