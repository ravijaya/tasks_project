def smile():
    return ":)"

def frown():
    return ":("

if __name__ == '__main__':
    pass
