import unittest


class SimplisticTest(unittest.TestCase):
    def test_demo(self):
        self.failUnless(True)


class OutcomesTest(unittest.TestCase):
    def testPass(self):
        return

    def testFail(self):
        self.failIf(False)

    @unittest.skip('causes an error')
    def testError(self):
        raise RuntimeError('Test error!')
        #pass
if __name__ == '__main__':
    unittest.main()
