def some_func():
    return 42
