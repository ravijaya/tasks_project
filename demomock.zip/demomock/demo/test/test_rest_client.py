import pytest
import mock
from demorestclient import CustomRestClient
import requests

# Option 1: Mocking Instance Methods


@mock.patch.object(CustomRestClient, 'get_tasks')
def test_get_tasks(mock_get_tasks, capsys):
    client = CustomRestClient()
    url = 'http://127.0.0.1:5000/todo/api/v1.0/tasks'

    mock_get_tasks.return_value = '', 200

    with capsys.disabled():
        response = client.get_tasks(url)
        print response

    mock_get_tasks.assert_called_with(url)

# Option 2: Creating Mock Instances


def test_get_tasks_2(capsys):
    mock_client = mock.create_autospec(CustomRestClient)
    url = 'http://127.0.0.1:5000/todo/api/v1.0/tasks'
    mock_client.get_tasks.return_value = "{}", 201

    response = mock_client.get_tasks(url)
    with capsys.disabled():
        print response

    mock_client.get_tasks.assert_called_with(url)




