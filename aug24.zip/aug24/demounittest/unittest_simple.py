import unittest



class SimplisticTest(unittest.TestCase):
    def test_demo(self):
        self.failUnless(True)

if __name__ == '__main__':
    unittest.main()
