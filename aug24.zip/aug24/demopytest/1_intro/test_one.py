from sys import version

def test_passing(capsys):
    assert (1, 2, 3) == (1, 2, 3)
    with capsys.disabled():
        print ">>", version, "<<"

def test_failing():
    assert (1, 2, 3) == (3, 2, 1)